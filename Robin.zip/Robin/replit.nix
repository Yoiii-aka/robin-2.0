{pkgs}: {
  deps = [
    pkgs.libopus
    pkgs.ffmpeg
    pkgs.libsodium
    pkgs.ffmpeg-full
  ];
}
