import discord
from discord.ext import commands
import os
import asyncio
import discord.opus
import ctypes.util
from keep_alive import keep_alive
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Initialize bot with command prefix '!' and enhanced reconnect settings
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    description="""
🎵 Music Commands:
!play [url] - Play song
!pause - Pause ⏸️
!resume - Resume ▶️
!skip - Next song ⏭️
!back - Previous song ⏮️
!stop - Stop & clear ⏹️
!loop - Toggle loop 🔁
!queue - Show queue 📑
!add [url] - Add to queue
!join - Join voice 🎧
!leave - Leave voice 👋
    """,
    reconnect=True
)

# Load OPUS
def setup_opus():
    if discord.opus.is_loaded():
        return True

    opus_paths = [
        'opus', 
        'libopus.so.0',
        ctypes.util.find_library('opus'),
        '/usr/lib/libopus.so.0',
        '/usr/local/lib/libopus.so.0'
    ]

    for opus_path in opus_paths:
        try:
            discord.opus.load_opus(opus_path)
            if discord.opus.is_loaded():
                logging.info(f"Successfully loaded OPUS from: {opus_path}")
                return True
        except Exception as e:
            logging.warning(f"Failed to load OPUS from {opus_path}: {e}")
            continue

    return False

# Load music cog
async def load_extensions():
    try:
        await bot.load_extension('cogs.music')
        logging.info("Successfully loaded music cog")
    except Exception as e:
        logging.error(f"Failed to load music cog: {e}")

@bot.event
async def on_ready():
    logging.info(f'{bot.user} has connected to Discord!')
    opus_loaded = setup_opus()
    logging.info(f'OPUS loaded: {opus_loaded}')
    if not opus_loaded:
        logging.warning("WARNING: OPUS failed to load. Voice functionality may not work correctly.")

    activity = discord.Activity(
        type=discord.ActivityType.playing,
        name="๋࣭ ⭑⚝💜Tonight, souls shall embrace.✮⋆˙💿"
    )
    await bot.change_presence(activity=activity)

@bot.event
async def on_error(event, *args, **kwargs):
    logging.error(f"Error in {event}: ", exc_info=True)

@bot.event
async def on_disconnect():
    logging.warning("Bot disconnected from Discord. Attempting to reconnect...")

async def main():
    try:
        # Start the keep-alive server
        keep_alive()
        logging.info("Keep-alive server started")

        # Start bot with automatic reconnection
        async with bot:
            await load_extensions()
            await bot.start(os.environ['DISCORD_TOKEN'])
    except Exception as e:
        logging.error(f"Critical error in main: {e}")
        # Wait before attempting to restart
        await asyncio.sleep(5)
        await main()

if __name__ == "__main__":
    while True:
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            logging.info("Bot shutting down...")
            break
        except Exception as e:
            logging.error(f"Critical error, restarting bot: {e}")
            continue