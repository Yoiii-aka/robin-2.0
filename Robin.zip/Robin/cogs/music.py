import discord
from discord.ext import commands
import asyncio
from utils.queue_manager import QueueManager
from utils.youtube_handler import YouTubeHandler
from utils.embed_creator import EmbedCreator

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queue_managers = {}
        self.youtube_handler = YouTubeHandler()
        self.embed_creator = EmbedCreator()
        self.inactive_check_task = self.bot.loop.create_task(self.check_inactive_voice_clients())

    def get_queue_manager(self, guild_id):
        if guild_id not in self.queue_managers:
            self.queue_managers[guild_id] = QueueManager()
        return self.queue_managers[guild_id]

    async def check_inactive_voice_clients(self):
        while not self.bot.is_closed():
            for guild_id, queue_manager in self.queue_managers.items():
                if queue_manager.last_activity and \
                   (asyncio.get_event_loop().time() - queue_manager.last_activity) > 300:  # 5 minutes
                    guild = self.bot.get_guild(guild_id)
                    if guild and guild.voice_client:
                        await guild.voice_client.disconnect()
                        del self.queue_managers[guild_id]
            await asyncio.sleep(60)

    @commands.command(name='play')
    async def play(self, ctx, *, url):
        try:
            if not ctx.author.voice:
                await ctx.send(embed=self.embed_creator.create_error("You need to be in a voice channel! 🎵"))
                return

            queue_manager = self.get_queue_manager(ctx.guild.id)
            queue_manager.update_activity()

            if not ctx.voice_client:
                try:
                    # Enhanced voice client configuration with explicit opus support
                    voice_client = await ctx.author.voice.channel.connect(
                        timeout=20.0,
                        reconnect=True,
                        self_deaf=True,
                        self_mute=False
                    )

                    if not voice_client.is_connected():
                        raise Exception("Voice client failed to establish a stable connection")

                    # Test voice client state
                    if not hasattr(voice_client, 'play'):
                        raise Exception("Voice client doesn't have required play attribute")

                    print(f"Successfully connected to voice channel: {ctx.author.voice.channel.name}")
                    print(f"Voice client state: Connected={voice_client.is_connected()}")

                except Exception as e:
                    print(f"Voice connection error: {str(e)}")
                    await ctx.send(embed=self.embed_creator.create_error("Failed to join voice channel. Please make sure I have the correct permissions! 🎵"))
                    return

            try:
                song_info = await self.youtube_handler.extract_info(url)
                queue_manager.add_to_queue(song_info)

                await ctx.send(embed=self.embed_creator.create_queue_add(song_info))

                if not ctx.voice_client.is_playing():
                    await self.play_next(ctx)

            except Exception as e:
                print(f"Error adding song: {str(e)}")
                await ctx.send(embed=self.embed_creator.create_error(f"Error: {str(e)} 😢"))

        except Exception as e:
            print(f"Play command error: {str(e)}")
            await ctx.send(embed=self.embed_creator.create_error("An unexpected error occurred while trying to play music 😢"))

    async def play_next(self, ctx):
        try:
            queue_manager = self.get_queue_manager(ctx.guild.id)

            if queue_manager.is_empty():
                return

            if not ctx.voice_client or not ctx.voice_client.is_connected():
                print("Voice client is not connected or is None")
                return

            song_info = queue_manager.get_current()

            try:
                source = await self.youtube_handler.create_audio_source(song_info['url'])

                def after_callback(error):
                    if error:
                        print(f"Error in play callback: {error}")
                    fut = asyncio.run_coroutine_threadsafe(
                        self.play_next(ctx), self.bot.loop)
                    try:
                        fut.result()
                    except Exception as e:
                        print(f"Error in callback future: {e}")

                ctx.voice_client.play(source, after=after_callback)
                await ctx.send(embed=self.embed_creator.create_now_playing(song_info))

            except Exception as e:
                print(f"Error playing next song: {e}")
                await ctx.send(embed=self.embed_creator.create_error(f"Error playing song: {str(e)} 😢"))
                queue_manager.advance_queue()  # Skip the problematic song
                await self.play_next(ctx)

        except Exception as e:
            print(f"Error in play_next: {e}")

    @commands.command(name='pause')
    async def pause(self, ctx):
        if ctx.voice_client and ctx.voice_client.is_playing():
            ctx.voice_client.pause()
            await ctx.send(embed=self.embed_creator.create_basic("Paused ⏸️"))
            self.get_queue_manager(ctx.guild.id).update_activity()

    @commands.command(name='resume')
    async def resume(self, ctx):
        if not ctx.voice_client:
            await ctx.send(embed=self.embed_creator.create_error("I'm not in a voice channel! 🎵"))
            return

        if ctx.voice_client.is_playing():
            await ctx.send(embed=self.embed_creator.create_error("Already playing! 🎵"))
            return

        if not ctx.voice_client.is_paused():
            await ctx.send(embed=self.embed_creator.create_error("Nothing to resume! 🎵"))
            return

        ctx.voice_client.resume()
        await ctx.send(embed=self.embed_creator.create_basic("Resumed ▶️"))
        self.get_queue_manager(ctx.guild.id).update_activity()

    @commands.command(name='skip')
    async def skip(self, ctx):
        if not ctx.voice_client:
            await ctx.send(embed=self.embed_creator.create_error("I'm not playing anything! 🎵"))
            return

        if not (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
            await ctx.send(embed=self.embed_creator.create_error("Nothing to skip! 🎵"))
            return

        queue_manager = self.get_queue_manager(ctx.guild.id)
        next_song = queue_manager.advance_queue()

        ctx.voice_client.stop()
        await ctx.send(embed=self.embed_creator.create_basic(
            "Skipped ⏭️" + (f"\nNext up: {next_song['title']}" if next_song else "")
        ))
        queue_manager.update_activity()

    @commands.command(name='queue')
    async def queue(self, ctx):
        queue_manager = self.get_queue_manager(ctx.guild.id)
        await ctx.send(embed=self.embed_creator.create_queue(queue_manager.get_queue()))
        queue_manager.update_activity()

    @commands.command(name='leave')
    async def leave(self, ctx):
        if ctx.voice_client:
            await ctx.voice_client.disconnect()
            if ctx.guild.id in self.queue_managers:
                del self.queue_managers[ctx.guild.id]
            await ctx.send(embed=self.embed_creator.create_basic("Bye bye! 👋"))

    @commands.command(name='join')
    async def join(self, ctx, *, channel_name=None):
        try:
            if ctx.voice_client:
                await ctx.send(embed=self.embed_creator.create_error("I'm already in a voice channel! 🎵"))
                return

            if channel_name:
                channel = discord.utils.get(ctx.guild.voice_channels, name=channel_name)
                if not channel:
                    await ctx.send(embed=self.embed_creator.create_error(f"Couldn't find voice channel '{channel_name}' 😢"))
                    return
            else:
                if not ctx.author.voice:
                    await ctx.send(embed=self.embed_creator.create_error("You need to be in a voice channel or specify one! 🎵"))
                    return
                channel = ctx.author.voice.channel

            try:
                # Enhanced error logging for voice connection
                print(f"Attempting to connect to channel: {channel.name}")
                print(f"Bot permissions in channel: {channel.permissions_for(ctx.guild.me)}")

                # Enhanced voice client configuration with explicit opus support
                voice_client = await channel.connect(
                    timeout=20.0,
                    reconnect=True,
                    self_deaf=True,
                    self_mute=False
                )

                if not voice_client.is_connected():
                    raise Exception("Voice client failed to establish a stable connection")

                # Test voice client state
                if not hasattr(voice_client, 'play'):
                    raise Exception("Voice client doesn't have required play attribute")

                print(f"Successfully connected to channel: {channel.name}")
                print(f"Voice client state: Connected={voice_client.is_connected()}")

                self.get_queue_manager(ctx.guild.id).update_activity()
                await ctx.send(embed=self.embed_creator.create_basic(f"Successfully joined {channel.name} 🎵"))

            except Exception as e:
                print(f"Detailed voice connection error: {str(e)}")
                print(f"Voice client state after error: {ctx.voice_client}")

                await ctx.send(embed=self.embed_creator.create_error(
                    "Failed to establish voice connection. Please ensure the bot has proper permissions. 😢"
                ))

                # Cleanup if connection failed
                if ctx.voice_client:
                    await ctx.voice_client.disconnect()

        except Exception as e:
            print(f"General error in join command: {str(e)}")
            await ctx.send(embed=self.embed_creator.create_error(
                "An unexpected error occurred while trying to join the channel 😢"
            ))

    @commands.command(name='add')
    async def add(self, ctx, *, url):
        queue_manager = self.get_queue_manager(ctx.guild.id)
        queue_manager.update_activity()

        try:
            song_info = await self.youtube_handler.extract_info(url)
            queue_manager.add_to_queue(song_info)

            await ctx.send(embed=self.embed_creator.create_queue_add(song_info))

        except Exception as e:
            await ctx.send(embed=self.embed_creator.create_error(f"Error: {str(e)} 😢"))

    @commands.command(name='stop')
    async def stop(self, ctx):
        if not ctx.voice_client:
            await ctx.send(embed=self.embed_creator.create_error("I'm not playing anything! 🎵"))
            return

        queue_manager = self.get_queue_manager(ctx.guild.id)
        queue_manager.clear_queue()

        if ctx.voice_client.is_playing() or ctx.voice_client.is_paused():
            ctx.voice_client.stop()
            await ctx.send(embed=self.embed_creator.create_basic("Stopped the music and cleared the queue ⏹️"))
        else:
            await ctx.send(embed=self.embed_creator.create_basic("Queue cleared! ✨"))

        queue_manager.update_activity()

    @commands.command(name='back')
    async def back(self, ctx):
        if not ctx.voice_client:
            await ctx.send(embed=self.embed_creator.create_error("I'm not playing anything! 🎵"))
            return

        if not (ctx.voice_client.is_playing() or ctx.voice_client.is_paused()):
            await ctx.send(embed=self.embed_creator.create_error("Nothing is currently playing! 🎵"))
            return

        queue_manager = self.get_queue_manager(ctx.guild.id)
        previous_song = queue_manager.previous_song()

        if previous_song:
            ctx.voice_client.stop()
            source = await self.youtube_handler.create_audio_source(previous_song['url'])
            ctx.voice_client.play(source, after=lambda e: asyncio.run_coroutine_threadsafe(
                self.play_next(ctx), self.bot.loop))
            await ctx.send(embed=self.embed_creator.create_basic(
                "Playing previous song ⏮️\nPlaying: " + previous_song['title']
            ))
        else:
            await ctx.send(embed=self.embed_creator.create_error("No previous song in queue! 🎵"))

        queue_manager.update_activity()

    @commands.command(name='loop')
    async def loop(self, ctx):
        queue_manager = self.get_queue_manager(ctx.guild.id)
        current_song = queue_manager.get_current()

        if not current_song:
            await ctx.send(embed=self.embed_creator.create_error("Nothing is currently playing! 🎵"))
            return

        is_looping = queue_manager.toggle_loop()
        status = "enabled 🔁" if is_looping else "disabled ➡️"

        await ctx.send(embed=self.embed_creator.create_basic(
            f"Loop {status}\nCurrently playing: {current_song['title']}"
        ))
        queue_manager.update_activity()


async def setup(bot):
    await bot.add_cog(Music(bot))