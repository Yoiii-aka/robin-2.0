# Discord Music Bot

A sophisticated Discord music bot designed for seamless audio streaming and interactive music experience.

## Files Structure

### Main Files
- `bot.py` - Main bot initialization and event handling
- `keep_alive.py` - Flask server for 24/7 uptime

### Cogs
- `cogs/music.py` - Music commands and playback functionality

### Utilities
- `utils/youtube_handler.py` - YouTube video processing and audio extraction
- `utils/queue_manager.py` - Music queue management system
- `utils/embed_creator.py` - Discord embed message creator

## Features
- YouTube audio streaming
- Queue management
- Play/Pause/Resume controls
- Skip/Previous track navigation
- Loop mode
- 24/7 operation capability

## Commands
- `!play [url]` - Play a song
- `!pause` - Pause playback
- `!resume` - Resume playback
- `!skip` - Skip to next song
- `!back` - Go to previous song
- `!stop` - Stop and clear queue
- `!loop` - Toggle loop mode
- `!queue` - Show current queue
- `!add [url]` - Add song to queue
- `!join` - Join voice channel
- `!leave` - Leave voice channel

## Required Environment Variables
- `DISCORD_TOKEN` - Your Discord bot token

## Dependencies
- discord.py
- yt-dlp
- Flask
- FFmpeg
- PyNaCl

## Code Overview

### 1. bot.py
```python
import discord
from discord.ext import commands
import os
import asyncio
import discord.opus
import ctypes.util
from keep_alive import keep_alive
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Initialize bot with command prefix '!' and enhanced reconnect settings
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(
    command_prefix='!',
    intents=intents,
    description="""
🎵 Music Commands:
!play [url] - Play song
!pause - Pause ⏸️
!resume - Resume ▶️
!skip - Next song ⏭️
!back - Previous song ⏮️
!stop - Stop & clear ⏹️
!loop - Toggle loop 🔁
!queue - Show queue 📑
!add [url] - Add to queue
!join - Join voice 🎧
!leave - Leave voice 👋
    """,
    reconnect=True
)

# ... Rest of bot.py code (OPUS setup, events, main loop) ...
```

### 2. cogs/music.py
```python
import discord
from discord.ext import commands
import asyncio
from utils.queue_manager import QueueManager
from utils.youtube_handler import YouTubeHandler
from utils.embed_creator import EmbedCreator

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queue_managers = {}
        self.youtube_handler = YouTubeHandler()
        self.embed_creator = EmbedCreator()
        self.inactive_check_task = self.bot.loop.create_task(self.check_inactive_voice_clients())

    # ... Rest of music.py code (commands and helper functions) ...
```

### 3. utils/youtube_handler.py
```python
import yt_dlp
import discord
import logging

class YouTubeHandler:
    def __init__(self):
        self.ydl_opts = {
            'format': 'bestaudio/best',
            'extractaudio': True,
            'audioformat': 'mp3',
            # ... Rest of options ...
        }
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('YouTubeHandler')

    # ... Rest of youtube_handler.py code ...
```

### 4. utils/queue_manager.py
```python
import asyncio

class QueueManager:
    def __init__(self):
        self.queue = []
        self.current_index = 0
        self.last_activity = None
        self.loop_current = False

    # ... Rest of queue_manager.py code ...
```

### 5. utils/embed_creator.py
```python
import discord

class EmbedCreator:
    def __init__(self):
        self.color = discord.Color.purple()
        self.footer_text = "🎵 Cute Music Bot 🎵"

    # ... Rest of embed_creator.py code ...
```

### 6. keep_alive.py
```python
from flask import Flask
from threading import Thread

app = Flask(__name__)

@app.route('/')
def home():
    return "Bot is alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()
```

These files work together to create a fully functional Discord music bot with streaming capabilities, queue management, and 24/7 operation. The code is organized into modular components for easier maintenance and scalability.
