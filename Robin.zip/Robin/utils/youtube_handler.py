import yt_dlp
import discord
import logging

class YouTubeHandler:
    def __init__(self):
        self.ydl_opts = {
            'format': 'bestaudio/best',
            'extractaudio': True,
            'audioformat': 'mp3',
            'outtmpl': '%(extractor)s-%(id)s-%(title)s.%(ext)s',
            'restrictfilenames': True,
            'noplaylist': True,
            'nocheckcertificate': True,
            'ignoreerrors': False,
            'logtostderr': False,
            'quiet': True,
            'no_warnings': True,
            'default_search': 'auto',
            'source_address': '0.0.0.0',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }],
        }
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger('YouTubeHandler')

    async def extract_info(self, url):
        self.logger.info(f"Extracting info for URL: {url}")
        try:
            with yt_dlp.YoutubeDL(self.ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                if not info:
                    raise Exception("Could not extract video information")

                return {
                    'title': info.get('title', 'Unknown Title'),
                    'url': info.get('url', ''),
                    'thumbnail': info.get('thumbnail', ''),
                    'duration': info.get('duration', 0),
                    'webpage_url': info.get('webpage_url', '')
                }
        except Exception as e:
            self.logger.error(f"Error extracting info: {str(e)}")
            raise Exception(f"Could not process YouTube URL: {str(e)}")

    async def create_audio_source(self, url):
        try:
            # Simplified FFmpeg options for better compatibility
            ffmpeg_options = {
                'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
                'options': '-vn'
            }
            self.logger.info("Creating audio source with FFmpeg")
            return discord.FFmpegPCMAudio(url, **ffmpeg_options)
        except Exception as e:
            self.logger.error(f"Error creating audio source: {str(e)}")
            raise Exception(f"Could not create audio source: {str(e)}")