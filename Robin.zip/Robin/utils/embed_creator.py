import discord

class EmbedCreator:
    def __init__(self):
        self.color = discord.Color.purple()
        self.footer_text = "🎵 Cute Music Bot 🎵"

    def create_basic(self, message):
        return discord.Embed(
            description=message,
            color=self.color
        ).set_footer(text=self.footer_text)

    def create_error(self, error_message):
        return discord.Embed(
            title="Error",
            description=error_message,
            color=self.color
        ).set_footer(text=self.footer_text)

    def create_queue_add(self, song_info):
        embed = discord.Embed(
            title="Added to Queue ✨",
            description=f"🎵 {song_info['title']}",
            color=self.color
        )
        embed.add_field(
            name="Duration",
            value=f"⏱️ {int(song_info['duration'])//60}:{int(song_info['duration'])%60:02d}"
        )
        embed.set_thumbnail(url=song_info['thumbnail'])
        embed.set_footer(text=self.footer_text)
        return embed

    def create_now_playing(self, song_info):
        embed = discord.Embed(
            title="Now Playing 🎶",
            description=f"🎵 {song_info['title']}",
            color=self.color
        )
        embed.add_field(
            name="Duration",
            value=f"⏱️ {int(song_info['duration'])//60}:{int(song_info['duration'])%60:02d}"
        )
        embed.set_thumbnail(url=song_info['thumbnail'])
        embed.set_footer(text=self.footer_text)
        return embed

    def create_queue(self, queue):
        if not queue:
            return self.create_basic("Queue is empty! 🎵")

        embed = discord.Embed(
            title="Current Queue 📑",
            color=self.color
        )
        
        for i, song in enumerate(queue[:10], 1):
            embed.add_field(
                name=f"{i}. {song['title']}",
                value=f"⏱️ {int(song['duration'])//60}:{int(song['duration'])%60:02d}",
                inline=False
            )
            
        if len(queue) > 10:
            embed.add_field(
                name="And more...",
                value=f"Plus {len(queue) - 10} more songs",
                inline=False
            )
            
        embed.set_footer(text=self.footer_text)
        return embed
