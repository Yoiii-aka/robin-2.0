import asyncio

class QueueManager:
    def __init__(self):
        self.queue = []
        self.current_index = 0
        self.last_activity = None
        self.loop_current = False

    def add_to_queue(self, song):
        self.queue.append(song)

    def get_current(self):
        if self.current_index < len(self.queue):
            return self.queue[self.current_index]
        return None

    def advance_queue(self):
        if not self.loop_current:
            self.current_index += 1
        return self.get_current()

    def previous_song(self):
        if self.current_index > 0:
            self.current_index -= 1
            return self.get_current()
        return None

    def toggle_loop(self):
        self.loop_current = not self.loop_current
        return self.loop_current

    def is_empty(self):
        return self.current_index >= len(self.queue)

    def get_queue(self):
        return self.queue[self.current_index:]

    def clear_queue(self):
        self.queue = []
        self.current_index = 0
        self.loop_current = False

    def update_activity(self):
        self.last_activity = asyncio.get_event_loop().time()